#!/usr/bin/env python3
"""
RMNCAH-N AGGREGATES - monthly counts (numerators and denominators) by county and facility, labelled with the
indicator IDs of the Kenya RMNCAH-N Indicator Definitions workbook, for every indicator the HMIS data lake
supports (see RMNCAH_indicator_availability.xlsx). Facility-based counts - not survey (KDHS) estimates.

    python lake_run.py rmncah_aggregates.py                 # year 2026 (default)
    python lake_run.py rmncah_aggregates.py --year 2025 --counties baringo,nyeri

Output (output/):  RMNCAH_aggregates_<year>.xlsx  (National monthly, By county, By facility, Indicators)
                   + .csv (long), .db (SQLite), RMNCAH_growth_for_WHO_Anthro_<year>.csv (no names / IDs)
INCREMENTAL: downloads are kept in ./work_rmncah_agg/ - reruns read only new data files.
    python rmncah_aggregates.py --offline                 # recount from ./work_rmncah_agg/ only (no lake)

Changes 2026-11-10 (death indicators; the original is kept as rmncah_aggregates_backup_2026-11-08.py):
  * death notifications: a notification counts as MATERNAL only for a woman 10-55 - not when it is a neonatal /
    perinatal / stillbirth notification (their 'deceased pregnant' field describes the mother), not when the
    deceased is male or outside 10-55 (age from the patient record, else age_at_death_days).
  * stillbirth notifications: not on a woman's own (maternal / standard) notification - her 'stillborn' / 'baby
    outcome' fields describe her baby; a perinatal / neonatal form stays a stillbirth even when filed on her record.
  * age_at_death_days = 0 is what EMPTY notifications carry (no type, pregnancy status, period); it no longer makes
    them neonatal / early neonatal deaths unless the notification itself is a neonatal / perinatal one.
  * maternal deaths from linked records: women with no date of birth are kept (age unknown); a woman's records in
    another county are linked through her client-registry ID (CR...); 'any source' keeps the record's death date.
  * QA-01 / QA-02 / QA-03: deaths recorded (all causes), notifications that cannot be classified, facilities
    recording at least one death. In the .xlsx, death indicators are BLANK (no data) for a month in which that
    county / facility recorded no death of any cause, and every county has the death rows (0 = deaths were
    recorded, none of this kind). 'Run info' sheet: data cut-off and the last complete month.
  * output/RMNCAH_maternal_deaths_linelist_<year>_CONFIDENTIAL.csv: every counted maternal death with its evidence,
    plus possible ones NOT counted (no death date; notification rejected; sex / age conflicts) - for MPDSR review.
    It holds patient IDs: do not share outside the MPDSR / data team.
"""
import argparse, getpass, hashlib, os, re, sqlite3, sys, threading, time
from concurrent.futures import ThreadPoolExecutor, as_completed
import numpy as np, pandas as pd, pyarrow as pa, pyarrow.compute as pc, pyarrow.parquet as pq
import warnings
try:                                     # pandas 3: keep ordinary text (mixing text types otherwise fails)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        pd.set_option("future.infer_string", False)
except Exception:
    pass
import pyarrow.dataset as pads
try:                                     # needed to read the lake; --offline works without pyiceberg
    from pyiceberg.expressions import AlwaysTrue, NotEqualTo
    from pyiceberg.io.pyarrow import ArrowScan
except ImportError:
    AlwaysTrue = NotEqualTo = ArrowScan = None

_LOCK = threading.Lock()


def say(*x):
    with _LOCK:
        print(*x, flush=True)


try:                                                    # your HTN pipeline's connection, if copied here
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from step1_find_htn import open_table, retry
    CONNECTOR = "step1_find_htn.py"
except ImportError:
    CONNECTOR = "built-in"

    def retry(fn, what="", tries=8):
        """Retry a lake read a few times (network hiccups) before giving up."""
        for i in range(tries):
            try:
                return fn()
            except Exception as e:
                if i == tries - 1:
                    raise
                say(f"  retrying {what} ({type(e).__name__}: {str(e)[:80]}) ...")
                time.sleep(min(60, 5 * 2 ** i))       # 5, 10, 20, 40, 60 ... seconds

    _FS = None

    def _s3():
        """S3 connection from the endpoint and keys entered at the start."""
        global _FS
        if _FS is None:
            from pyarrow import fs as pafs
            url = os.environ["AWS_ENDPOINT_URL"]
            _FS = pafs.S3FileSystem(endpoint_override=re.sub(r"^https?://", "", url),
                                    scheme="https" if url.startswith("https") else "http",
                                    access_key=os.environ["AWS_ACCESS_KEY_ID"],
                                    secret_key=os.environ["AWS_SECRET_ACCESS_KEY"],
                                    region=os.environ.get("AWS_REGION", "us-east-1"),
                                    connect_timeout=30, request_timeout=180,          # patient over a VPN
                                    retry_strategy=pafs.AwsStandardS3RetryStrategy(max_attempts=10))
        return _FS

    # ---- tiny S3 client (standard library; signatures verified against the AWS library) for FAST lookups
    import datetime as _dt, hashlib, hmac, urllib.error, urllib.parse, urllib.request
    import xml.etree.ElementTree as ET
    EMPTY_SHA = hashlib.sha256(b"").hexdigest()

    def _q(s, safe="-_.~"):
        return urllib.parse.quote(s, safe=safe)

    class S3:
        def __init__(self, endpoint, access_key, secret_key, region="us-east-1", timeout=120, tries=8):
            u = urllib.parse.urlparse(endpoint if "://" in endpoint else "http://" + endpoint)
            self.scheme, self.host = u.scheme, u.netloc
            self.ak, self.sk, self.region = access_key, secret_key, region
            self.timeout, self.tries = timeout, tries
            self.requests = 0

        # ---------------------------------------------------------------- signing (SigV4)
        def sign(self, method, path, query, headers, now=None):
            """Return the headers (incl. Authorization) for a request. path is already URL-encoded."""
            t = now or _dt.datetime.now(_dt.timezone.utc)
            amz = t.strftime("%Y%m%dT%H%M%SZ")
            day = t.strftime("%Y%m%d")
            h = {k.lower(): str(v).strip() for k, v in headers.items()}
            h["host"] = self.host
            h["x-amz-date"] = amz
            h["x-amz-content-sha256"] = EMPTY_SHA
            signed = ";".join(sorted(h))
            canon_q = "&".join(f"{_q(k)}={_q(str(v))}" for k, v in sorted(query.items()))
            canon = "\n".join([method, path, canon_q, "".join(f"{k}:{h[k]}\n" for k in sorted(h)), signed, EMPTY_SHA])
            scope = f"{day}/{self.region}/s3/aws4_request"
            sts = "\n".join(["AWS4-HMAC-SHA256", amz, scope, hashlib.sha256(canon.encode()).hexdigest()])
            k = ("AWS4" + self.sk).encode()
            for part in (day, self.region, "s3", "aws4_request"):
                k = hmac.new(k, part.encode(), hashlib.sha256).digest()
            sig = hmac.new(k, sts.encode(), hashlib.sha256).hexdigest()
            h["authorization"] = f"AWS4-HMAC-SHA256 Credential={self.ak}/{scope}, SignedHeaders={signed}, Signature={sig}"
            return h

        def _request(self, method, bucket, key="", query=None, headers=None):
            query = {k: v for k, v in (query or {}).items() if v is not None}
            path = "/" + _q(bucket) + ("/" + _q(key, safe="-_.~/") if key else "/")
            if not key:
                path = "/" + _q(bucket)
            last = None
            for i in range(self.tries):
                h = self.sign(method, path, query, headers or {})
                url = f"{self.scheme}://{self.host}{path}" + (
                    "?" + "&".join(f"{_q(k)}={_q(str(v))}" for k, v in sorted(query.items())) if query else "")
                req = urllib.request.Request(url, method=method, headers=h)
                try:
                    self.requests += 1
                    with urllib.request.urlopen(req, timeout=self.timeout) as r:
                        return r.read(), dict(r.headers)
                except urllib.error.HTTPError as e:
                    body = e.read()[:300].decode("utf-8", "replace")
                    if e.code in (500, 502, 503, 504):
                        last = RuntimeError(f"HTTP {e.code}: {body}")
                    else:
                        raise RuntimeError(f"HTTP {e.code} from the data lake: {body}") from None
                except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
                    last = e
                time.sleep(min(30, 2 * 2 ** i))
            raise RuntimeError(f"network problem after {self.tries} tries: {last}")

        # ---------------------------------------------------------------- operations
        def list(self, bucket, prefix="", start_after=None, max_keys=1000, delimiter=None, token=None):
            """One ListObjectsV2 page -> (objects [{'Key','Size'}], prefixes [str], next_token or None)."""
            body, _ = self._request("GET", bucket, query={"list-type": "2", "prefix": prefix, "start-after": start_after,
                                                           "max-keys": max_keys, "delimiter": delimiter,
                                                           "continuation-token": token})
            root = ET.fromstring(body)
            ns = {"s": root.tag.split("}")[0].strip("{")} if root.tag.startswith("{") else {}
            f = (lambda p: f"s:{p}") if ns else (lambda p: p)
            objs = [{"Key": c.find(f("Key"), ns).text, "Size": int(c.find(f("Size"), ns).text)}
                    for c in root.findall(f("Contents"), ns)]
            pres = [p.find(f("Prefix"), ns).text for p in root.findall(f("CommonPrefixes"), ns)]
            trunc = (root.find(f("IsTruncated"), ns).text or "").lower() == "true"
            nxt = root.find(f("NextContinuationToken"), ns)
            return objs, pres, (nxt.text if trunc and nxt is not None else None)

        def folders(self, bucket, prefix):
            out, tok = [], None
            while True:
                _, pres, tok = self.list(bucket, prefix, delimiter="/", token=tok)
                out += [p[len(prefix):].rstrip("/") for p in pres]
                if not tok:
                    return out

        def get(self, bucket, key, start=None, end=None):
            h = {"Range": f"bytes={start}-{'' if end is None else end}"} if start is not None else {}
            body, _ = self._request("GET", bucket, key, headers=h)
            return body

    _LITE = None
    _META = re.compile(r"^(\d{5,})-[0-9a-fA-F-]{36}\.metadata\.json$")

    def _newest_metadata(bucket, meta_prefix):
        """Newest metadata file by binary search on its version number (~20 tiny requests) instead of
        listing the thousands of files in the table's metadata folder."""
        global _LITE
        if _LITE is None:
            _LITE = S3(os.environ["AWS_ENDPOINT_URL"], os.environ["AWS_ACCESS_KEY_ID"],
                       os.environ["AWS_SECRET_ACCESS_KEY"], timeout=180)

        def at_or_after(n):
            objs, _, _ = _LITE.list(bucket, meta_prefix, start_after=meta_prefix + f"{n:05d}", max_keys=50)
            for o in objs:
                m = _META.match(o["Key"][len(meta_prefix):])
                if m and int(m.group(1)) >= n:
                    return int(m.group(1)), o["Key"]
            return None
        try:                                                     # Hadoop-style tables keep a pointer file
            n = int(_LITE.get(bucket, meta_prefix + "version-hint.text").strip())
            return meta_prefix + f"v{n}.metadata.json"
        except Exception:
            pass
        first = at_or_after(0)
        if first is None:
            return None
        lo, best, hi = first[0], first[1], 99999
        while lo <= hi:
            mid = (lo + hi) // 2
            hit = at_or_after(mid)
            if hit:
                best, lo = hit[1], hit[0] + 1
            else:
                hi = mid - 1
        return best

    def open_table(a, path):
        """Open the newest version of an Iceberg table stored at s3://<bucket>/<path> (fast lookup)."""
        from pyiceberg.table import StaticTable
        prefix = f"{path.strip('/')}/metadata/"
        key = retry(lambda: _newest_metadata(a.bucket, prefix), f"finding the newest version of {path}")
        if not key:
            raise FileNotFoundError(f"no Iceberg table at s3://{a.bucket}/{path.strip('/')}")
        url = os.environ["AWS_ENDPOINT_URL"]
        return StaticTable.from_metadata(f"s3://{a.bucket}/{key}", properties={
            "s3.endpoint": url, "s3.access-key-id": os.environ["AWS_ACCESS_KEY_ID"],
            "s3.secret-access-key": os.environ["AWS_SECRET_ACCESS_KEY"],
            "s3.region": os.environ.get("AWS_REGION", "us-east-1"),
            "s3.connect-timeout": "30", "s3.request-timeout": "180"})


P = "iceberg/hmis_tiberbu_ingestion/"
WORK = "work_rmncah_agg"
TODAY = pd.Timestamp.today().normalize()
TODAY_S = TODAY.strftime("%Y-%m-%d")
CID = r"^county_id$"
YES = {"1", "true", "yes", "y", "t"}
# ---- diagnoses kept (text or ICD-10 / ICD-11 codes)
OBST = (r"\b(?:J[AB][0-9][0-9A-Z]|O[0-9]{2})\b|pregnan|obstetric|labou?r|eclampsia|postpartum|post-partum|post partum|"
        r"antepartum|puerper|abortion|miscarriage|ectopic|placenta|haemorrhage in pregnancy|ruptured uterus|"
        r"obstructed|caesarean|c-section|maternal death")
NOT_OBST = r"labou?ratory|lab test"
STILL = (r"still ?birth|stillborn|still born|\bfsb\b|\bmsb\b|macerat|\biufd\b|intra-?uterine (?:fetal|foetal) death|"
         r"(?:fetal|foetal) death|\bZ37\.[13467]\b|\bP95\b")
SEPSIS = r"sepsis|septic|septicaemia|septicemia|\bP36|\bKA60|\bKA61"
DIARR = r"diarrh|gastroenteritis|\bA09\b|\b1A40|\bME05\.1"
DXCOLS = ("diagnosis_code", "entry_code", "description_mapping", "description")
# ---- procedures (clinical_procedure.procedure_template values seen in the lake)
DELIVERY = r"deliver|caes|cesar|ceaser|caeser"
CSECTION = r"caes|cesar|ceaser|caeser"
FP_PROC = r"(?:insert\w*.*(?:implant|iucd)|(?:implant|iucd).*insert\w*|tubal|vasectom|jadelle)"
NOT_PROC = r"removal|orbital|cataract|intraocular|lens|cochlear|hysterectomy"
# ---- programmes, forms, drugs (values seen in the lake)
PROGRAMS = {"anc": r"^\s*anc\s*$", "pnc": r"^\s*pnc\s*$", "fp": r"^\s*family planning\s*$", "cwc": r"^\s*cwc\s*$",
            "epi": r"^\s*epi\s*$", "maternity": r"^\s*maternity forms\s*$", "nutrition": r"^\s*nutrition services\s*$",
            "pmtct": r"^\s*pmtct?\s*$"}
FORMS = {"bcg": r"^\s*bcg vaccine\s*$", "measles": r"^\s*measles vaccine\s*$|measles rubella",
         "deworm": r"^\s*deworming\s*$", "anc_deworm": r"antenatal deworming",
         "ifas": r"iron and folic acid", "vas": r"vitamin a supplementation", "ebf": r"exclusive breastfeeding",
         "llin": r"long lasting insecticidal net", "pnc_mother": r"postnatal care mother", "pnc_child": r"postnatal care child",
         "childbirth": r"^\s*childbirth\s*$", "fp": r"^\s*family planning\s*$", "kmc": r"\bkmc\b"}
DRUGS = {"ifas": r"ferrous|folic", "zinc": r"\bzinc\b", "ors": r"oral rehydration|\bors\b|glucose.*citrate|citrate.*glucose",
         "deworm": r"albendazole|mebendazole",
         "antibiotic": r"gentamicin|ampicillin|benzylpenicillin|benzyl penicillin|ceftriaxone",
         "fp": r"medroxyprogesterone|levonorgestrel|etonogestrel|desogestrel|ethinyl"}
NOT_DRUG = r"zinc oxide|calamine|%\s*w/[vw]|\beye\b|\bear\b|cream|ointment|lotion|shampoo"
DRUG_NOT = {"zinc": r"ferrous|ferric|folic|ascorbic|vitamin|multi", "ors": r"lactate",
            "antibiotic": r"benzathine"}                           # per-class exclusions (benzathine = syphilis)
ANY_FORM = "|".join(FORMS.values())
ANY_DRUG = "|".join(DRUGS.values())
ANY_PROG = "|".join(PROGRAMS.values())

TABLES = {
    "patients": ("patient", {"patient": r"^name$", "cid": CID, "sex": r"^sex$|^gender$", "dob": r"^dob$|date_of_birth",
                             "newborn": r"newborn", "parent": r"^custom_parent$|^parent$|mother",
                             "deceased": r"^custom_deceased$|^deceased$|^is_deceased$",
                             "death_date": r"death_date|deceased_date|date_of_death"}),
    "inpatient": ("inpatient_record", {"patient": r"^patient$", "cid": CID, "is_deceased": r"is_deceased|deceased$",
                                       "death_date": r"deceased_date|death_date", "facility": r"^company$",
                                       "cause": r"cause_of_death"}),
    "dx": ("diagnosis_entry", {"note_id": r"^parent$", "cid": CID, "parenttype": r"^parenttype$",
                               "diagnosis_code": r"^diagnosis_code$", "entry_code": r"^entry_code$",
                               "description_mapping": r"^description_mapping$", "description": r"^description$",
                               "docstatus": r"^docstatus$"}),
    "notes": ("doctors_notes", {"note_id": r"^name$", "cid": CID, "patient": r"^patient$", "encounter_id": r"encounter"}),
    "enc": ("patient_encounter", {"encounter_id": r"^name$", "cid": CID, "patient": r"^patient$",
                                  "date": r"^encounter_date$", "docstatus": r"^docstatus$", "facility": r"^company$"}),
    "vitals": ("vital_signs", {"patient": r"^patient$", "cid": CID, "date": r"^signs_date$", "docstatus": r"^docstatus$",
                               "systolic": r"^bp_systolic$", "diastolic": r"^bp_diastolic$", "bp": r"^bp$",
                               "height": r"^height$", "weight": r"^weight$", "muac": r"muac", "facility": r"^company$"}),
    "procedures": ("clinical_procedure", {"cid": CID, "patient": r"^patient$", "template": r"^procedure_template$",
                                          "date": r"^start_date$", "status": r"^status$", "docstatus": r"^docstatus$",
                                          "facility": r"^company$"}),
    "notifications": ("death_notification", {"cid": CID, "patient": r"^patient$", "date": r"^date_of_death$",
                                             "ntype": r"^notification_type$", "pregnant": r"^deceased_pregnant$",
                                             "stillborn": r"^stillborn$", "baby_outcome": r"^baby_outcome$",
                                             "period": r"^period_of_death$", "audited": r"^death_audited$",
                                             "facility": r"^hospital_of_demise$", "age_days": r"^age_at_death_days$",
                                             "docstatus": r"^docstatus$"}),
    "programs": ("health_program_enrollment", {"cid": CID, "patient": r"^patient$", "program": r"^program$",
                                               "date": r"^date_enrolled$", "voided": r"^voided$",
                                               "docstatus": r"^docstatus$", "facility": r"^company$"}),
    "forms": ("form_data_repository", {"cid": CID, "patient": r"^patient$", "form": r"^form_name$",
                                       "created": r"^creation$", "docstatus": r"^docstatus$", "facility": r"^company$"}),
    "drugs": ("doctor_drug_prescription", {"cid": CID, "patient": r"^patient$", "drug": r"^drug_name$",
                                           "date": r"^start_date$", "parent": r"^parent$", "docstatus": r"^docstatus$"}),
}
OPTIONAL = set(TABLES) - {"patients", "enc"}
VERSION = {k: f"{k}-agg-v1" for k in TABLES}
POOL = None


def strs(tbl):
    return tbl.cast(pa.schema([(c, pa.string()) for c in tbl.column_names]))


def m_regex(tbl, col, pattern):
    if col not in tbl.column_names:
        return pa.array(np.zeros(tbl.num_rows, dtype=bool))
    return pc.fill_null(pc.match_substring_regex(pc.cast(tbl[col], pa.string()), pattern, ignore_case=True), False)


def not_cancelled(tbl):
    if "docstatus" not in tbl.column_names:
        return pa.array(np.ones(tbl.num_rows, dtype=bool))
    return pc.fill_null(pc.not_equal(pc.cast(tbl["docstatus"], pa.string()), "2"), True)


def r_dx(tbl):          # pregnancy, stillbirth, sepsis and diarrhoea diagnoses only
    m = None
    for k in DXCOLS:
        r = pc.or_(pc.and_(pc.or_(m_regex(tbl, k, OBST), m_regex(tbl, k, STILL)), pc.invert(m_regex(tbl, k, NOT_OBST))),
                   pc.or_(m_regex(tbl, k, SEPSIS), m_regex(tbl, k, DIARR)))
        m = r if m is None else pc.or_(m, r)
    return tbl.filter(pc.and_(m, not_cancelled(tbl)))


def r_enc(tbl):
    return tbl.filter(not_cancelled(tbl))


def r_inpatient(tbl):   # deaths only
    m = pc.or_(pc.is_in(pc.utf8_lower(pc.cast(tbl["is_deceased"], pa.string())), value_set=pa.array(sorted(YES)))
               if "is_deceased" in tbl.column_names else pa.array(np.zeros(tbl.num_rows, dtype=bool)),
               pc.is_valid(tbl["death_date"]) if "death_date" in tbl.column_names else pa.array(np.zeros(tbl.num_rows, dtype=bool)))
    return tbl.filter(pc.fill_null(m, False))


def r_vitals(tbl):      # rows with a BP, height, weight or MUAC
    m = None
    for c in ("systolic", "bp", "height", "weight", "muac"):
        if c in tbl.column_names:
            v = pc.fill_null(pc.and_(pc.is_valid(tbl[c]), pc.not_equal(pc.cast(tbl[c], pa.string()), "")), False)
            m = v if m is None else pc.or_(m, v)
    if m is None:
        return tbl.slice(0, 0)
    return tbl.filter(pc.and_(pc.fill_null(m, False), not_cancelled(tbl)))


def r_procedures(tbl):  # deliveries and FP procedures
    keep = pc.and_(pc.or_(m_regex(tbl, "template", DELIVERY), m_regex(tbl, "template", FP_PROC)),
                   pc.invert(m_regex(tbl, "template", NOT_PROC)))
    return tbl.filter(pc.and_(keep, not_cancelled(tbl)))


def r_programs(tbl):
    return tbl.filter(pc.and_(m_regex(tbl, "program", ANY_PROG), not_cancelled(tbl)))


def r_forms(tbl):
    return tbl.filter(pc.and_(m_regex(tbl, "form", ANY_FORM), not_cancelled(tbl)))


def r_drugs(tbl):
    keep = pc.and_(m_regex(tbl, "drug", ANY_DRUG), pc.invert(m_regex(tbl, "drug", NOT_DRUG)))
    return tbl.filter(pc.and_(keep, not_cancelled(tbl)))


REDUCE = {"patients": None, "inpatient": r_inpatient, "dx": r_dx, "notes": None, "enc": r_enc, "vitals": r_vitals,
          "procedures": r_procedures, "notifications": None, "programs": r_programs, "forms": r_forms, "drugs": r_drugs}


def file_key(tk):
    dels = sorted(getattr(d, "file_path", str(d)) for d in (getattr(tk, "delete_files", None) or ()))
    return hashlib.md5("|".join([tk.file.file_path] + dels).encode()).hexdigest()[:16] + ".parquet"


def scan(a, step):
    """Read one table into work_linelist2/<step>/ (one compact parquet per data file). Only NEW or CHANGED
    data files are read; files that disappeared from the table are removed. Returns the list of cached files."""
    table, find = TABLES[step]
    out = os.path.join(WORK, step)
    if getattr(a, "offline", False):                     # --offline: use what is already downloaded
        sigf = os.path.join(out, "_VERSION")
        if not os.path.isdir(out):
            if step in OPTIONAL:
                say(f"[{step}] offline: nothing cached - skipped")
                return []
            raise SystemExit(f"--offline: no cached data for {step} in {out}")
        if os.path.exists(sigf) and open(sigf).read().strip() != VERSION[step]:
            raise SystemExit(f"--offline: the cache in {out} is from another version of this script - run online")
        files = sorted(os.path.join(out, f) for f in os.listdir(out) if f.endswith(".parquet") and not f.startswith("_"))
        say(f"[{step}] offline: {len(files)} cached files")
        return files
    os.makedirs(out, exist_ok=True)
    sigf = os.path.join(out, "_VERSION")
    if os.path.exists(sigf) and open(sigf).read().strip() != VERSION[step]:
        for f in os.listdir(out):
            os.remove(os.path.join(out, f))
    open(sigf, "w").write(VERSION[step])
    try:
        t = open_table(a, P + table)
    except Exception as e:
        if step in OPTIONAL:
            say(f"[{step}] table {table} not available ({type(e).__name__}) - skipped")
            return []
        raise
    names = [f.name for f in t.schema().fields]
    cols = {k: next((c for c in names if re.search(p, c, re.I)), None) for k, p in find.items()}
    cols = {k: v for k, v in cols.items() if v}
    miss = [k for k in find if k not in cols]
    say(f"[{step}] {table}: using " + ", ".join(f"{k}<-{v}" for k, v in cols.items())
        + (f" | NOT FOUND: {', '.join(miss)}" if miss else ""))
    flt = NotEqualTo(cols["docstatus"], 2) if "docstatus" in cols and step in ("enc", "lab", "dx") else AlwaysTrue()
    try:
        sc = t.scan(row_filter=flt, selected_fields=tuple(dict.fromkeys(cols.values())))
    except Exception:
        sc = t.scan(selected_fields=tuple(dict.fromkeys(cols.values())))
    tasks = retry(lambda: list(sc.plan_files()), f"planning {table}")
    reader = ArrowScan(t.metadata, t.io, sc.projection(), sc.row_filter, sc.case_sensitive)
    want = {file_key(tk): tk for tk in tasks}
    have = {f for f in os.listdir(out) if f.endswith(".parquet") and not f.startswith("_")}
    for f in have - set(want):
        os.remove(os.path.join(out, f))
    todo = [tk for k, tk in want.items() if k not in have]
    ren = {v: k for k, v in cols.items()}
    say(f"[{step}] {len(tasks)} files: {len(tasks) - len(todo)} already read, {len(todo)} new")

    def one(tk):
        batches = retry(lambda: list(reader.to_record_batches([tk])), f"reading a {table} file")
        tbl = pa.Table.from_batches(batches) if batches else pa.table({c: pa.array([], pa.string()) for c in cols.values()})
        tbl = strs(tbl)
        tbl = pa.table({k: tbl[c] for k, c in cols.items() if c in tbl.column_names})   # one column per field
        if REDUCE[step] is not None and tbl.num_rows:
            tbl = strs(REDUCE[step](tbl))
        final = os.path.join(out, file_key(tk))
        tmp = os.path.join(out, "_" + os.path.basename(final))
        pq.write_table(tbl, tmp)
        os.replace(tmp, final)
        return tbl.num_rows

    t0, rows = time.time(), 0
    futs = [POOL.submit(one, tk) for tk in todo]
    for n, f in enumerate(as_completed(futs), 1):
        rows += f.result()
        if n % 25 == 0 or n == len(todo):
            el = time.time() - t0
            say(f"  [{step}] {n}/{len(todo)} new files | {rows:,} rows kept | {el / 60:.1f} min")
    return [os.path.join(out, k) for k in want]


def load(files, cols=None, where=None):
    """Read cached files, filtered on disk: where = {column: set_of_values}."""
    files = [f for f in files if os.path.getsize(f) > 0]
    if not files:
        return pd.DataFrame(columns=cols or [])
    ds = pads.dataset(files, format="parquet")
    expr = None
    for c, vals in (where or {}).items():
        if c not in ds.schema.names:
            return pd.DataFrame(columns=cols or ds.schema.names)
        e = pc.field(c).isin(pa.array(sorted(map(str, vals)), pa.string()))
        expr = e if expr is None else expr & e
    use = [c for c in (cols or ds.schema.names) if c in ds.schema.names]
    df = ds.to_table(columns=use, filter=expr).to_pandas()
    for c in cols or []:
        if c not in df:
            df[c] = None
    return df.replace({"None": None, "nan": None, "": None})


# ------------------------------------------------------------------ helpers
YESV = sorted(YES | {s.upper() for s in YES} | {s.capitalize() for s in YES} | {"1.0"})


DATE_MIN, DATE_MAX = pd.Timestamp("1900-01-01"), pd.Timestamp("2100-12-31")


def day(s):
    """Date part of a text column as datetime64[ns]. Dates outside 1900-2100 (typos such as year 0026) become
    missing: pandas 3 parses them at microsecond precision, and they later overflow when mixed with ns dates."""
    raw = s if isinstance(s, pd.Series) else pd.Series(s)
    d = pd.to_datetime(raw.astype(str).str[:10], errors="coerce")
    d = d.where(d.isna() | ((d >= DATE_MIN) & (d <= DATE_MAX))).astype("datetime64[ns]")
    return d if isinstance(s, pd.Series) else d.values


def number(s):
    return pd.to_numeric(s.astype(str).str.extract(r"(-?\d+(?:\.\d+)?)", expand=False), errors="coerce").astype(float)


def is_yes(s):
    return s.astype(str).str.strip().str.lower().isin(YES | {"1.0"})


def pkey(df, pcol="patient"):
    return list(zip(df["cid"].fillna(""), df[pcol].astype(str)))


def lkey(keys):
    """Person key for linking across counties: the client-registry ID (CR...) where there is one - the same woman
    in any county instance - else (county, patient)."""
    return [k[1] if isinstance(k, tuple) and str(k[1]).startswith("CR") else k for k in keys]


def classify(text, table):
    """names of the classes (keys of table) whose pattern matches"""
    t = text.fillna("").astype(str)
    out = {}
    for k, p in table.items():
        m = t.str.contains(p, case=False, regex=True)
        if table is DRUGS and k in DRUG_NOT:
            m &= ~t.str.contains(DRUG_NOT[k], case=False, regex=True)
        out[k] = m
    return pd.DataFrame(out, index=text.index)


def within(a, b, a_date, b_date, lo, hi):
    """rows of a that have a row of b for the same patient with b_date - a_date in [lo, hi] days."""
    if len(a) == 0 or len(b) == 0:
        return pd.Series(False, index=a.index)
    m = a[["key", a_date]].reset_index().merge(b[["key", b_date]].rename(columns={b_date: "_bd"}), on="key")
    m = m[(m["_bd"] - m[a_date]).dt.days.between(lo, hi)]
    return pd.Series(a.index.isin(set(m["index"])), index=a.index)


def main():
    ap = argparse.ArgumentParser(description="RMNCAH-N aggregate counts from the data lake")
    ap.add_argument("--year", type=int, default=2026)
    ap.add_argument("--counties", help="comma list of county_id values, e.g. baringo,nyeri")
    ap.add_argument("--bucket", default=os.environ.get("ICEBERG_BUCKET") or "dha-analytics")
    ap.add_argument("--endpoint")
    ap.add_argument("--workers", type=int, default=6, help="data files downloaded at the same time (default 6)")
    ap.add_argument("--tables-at-once", type=int, default=2, help="tables read at the same time (default 2)")
    ap.add_argument("--offline", action="store_true", help="count from the cached downloads only (no lake connection)")
    a = ap.parse_args()
    if not a.offline:
        if ArrowScan is None:
            raise SystemExit("pyiceberg is not installed: pip install pyiceberg (or run with --offline)")
        os.environ["AWS_ENDPOINT_URL"] = a.endpoint or os.environ.get("AWS_ENDPOINT_URL") or \
            input("S3 endpoint [http://10.10.100.102:8000]: ").strip() or "http://10.10.100.102:8000"
        if "AWS_ACCESS_KEY_ID" not in os.environ:
            os.environ["AWS_ACCESS_KEY_ID"] = input("Access key: ").strip()
        if "AWS_SECRET_ACCESS_KEY" not in os.environ:
            os.environ["AWS_SECRET_ACCESS_KEY"] = getpass.getpass("Secret key: ").strip()
    global POOL
    POOL = ThreadPoolExecutor(a.workers)
    T0 = time.time()
    y0, y1 = pd.Timestamp(a.year, 1, 1), min(pd.Timestamp(a.year, 12, 31), TODAY)
    say(f"Connection: {CONNECTOR} | year {a.year}: {y0:%d %b} to {y1:%d %b %Y}")

    with ThreadPoolExecutor(max(1, a.tables_at_once)) as steps:
        fut = {s: steps.submit(scan, a, s) for s in TABLES}
        F = {s: f.result() for s, f in fut.items()}
    say(f"\nTables up to date in {(time.time() - T0) / 60:.1f} min. Counting ...")

    # ---------------- data cut-off = the latest record date in the data. Deaths dated after it are not counted
    #                  (they are typing errors, e.g. day and month swapped), and the month it falls in is partial.
    cands = []
    for s, c in (("procedures", "date"), ("programs", "date"), ("forms", "created")):
        x = load(F[s], [c])
        if len(x):
            x = day(x[c])
            x = x[x <= TODAY]
            if len(x) and pd.notna(x.max()):
                cands.append(x.max())
    DATA_TO = max(cands) if cands else TODAY
    END = min(TODAY, DATA_TO)
    month_end = (DATA_TO + pd.offsets.MonthEnd(0)).normalize()
    PARTIAL = DATA_TO.strftime("%Y-%m") if DATA_TO < month_end else None
    LAST_COMPLETE = (DATA_TO.to_period("M") - (1 if PARTIAL else 0)).strftime("%Y-%m")
    say(f"[cut-off] latest record {DATA_TO:%d %b %Y} | last complete month {LAST_COMPLETE}"
        + (f" | {PARTIAL} is partial" if PARTIAL else ""))

    # ---------------- patients (dob, sex), deaths from patient / inpatient records
    pfiles = [f for f in F["patients"] if os.path.getsize(f) > 0]
    pcols = ["cid", "patient", "sex", "dob", "newborn", "parent", "deceased", "death_date"]
    PT = pads.dataset(pfiles, format="parquet").to_table() if pfiles else pa.table({c: pa.array([], pa.string()) for c in pcols})
    PT = PT.select([c for c in pcols if c in PT.column_names])
    for c in pcols:
        if c not in PT.column_names:
            PT = PT.append_column(c, pa.array([None] * PT.num_rows, pa.string()))
    say(f"[patients] {PT.num_rows:,}")

    def ptab(mask):
        """rows of the patient table as pandas (only the ones asked for)."""
        d = PT.filter(mask).to_pandas().astype(object).replace({"None": None, "nan": None, "": None})
        d["cid"] = d["cid"].fillna("")
        d = d.drop_duplicates(["cid", "patient"])
        d["dob_d"] = day(d["dob"])
        d["female"] = d["sex"].astype(str).str.lower().str.startswith("f")
        d["key"] = pkey(d)
        return d

    def lower_in(col, values):
        return pc.fill_null(pc.is_in(pc.utf8_lower(pc.utf8_trim_whitespace(pc.cast(PT[col], pa.string()))),
                                     value_set=pa.array(sorted(values))), False)

    P_ = pd.DataFrame({"dob_d": pd.Series(dtype="datetime64[ns]"), "female": pd.Series(dtype=object),
                       "sex": pd.Series(dtype=object)}, index=pd.Index([], dtype=object))

    def need_people(keys):
        """make sure dob / sex of these people are in P_ (loaded on demand, in one filter)."""
        nonlocal P_
        missing = {k for k in keys if k not in P_.index}
        if not missing:
            return
        d = ptab(pc.fill_null(pc.is_in(pc.cast(PT["patient"], pa.string()),
                                       value_set=pa.array(sorted({k[1] for k in missing}))), False))
        d = d[d["key"].isin(missing)].set_index("key")[["dob_d", "female", "sex"]]
        P_ = pd.concat([P_, d])
        P_ = P_[~P_.index.duplicated()]

    def with_person(df):
        """attach dob / female and age at the event (df needs key and d)."""
        need_people(set(df["key"]))
        df = df.join(P_, on="key")
        df["dob_d"] = pd.to_datetime(df["dob_d"], errors="coerce")
        df["d"] = pd.to_datetime(df["d"], errors="coerce")
        df["age_days"] = (df["d"] - df["dob_d"]).dt.days
        df["age_y"] = df["age_days"] / 365.25
        return df

    def enc_for(where):
        e = load(F["enc"], ["cid", "encounter_id", "patient", "date", "facility"], where)
        e["cid"] = e["cid"].fillna("")
        e = e.drop_duplicates(["cid", "encounter_id"])
        e["d"] = day(e["date"])
        return e

    # ---------------- registered newborns (live births in the system)
    nb = ptab(lower_in("newborn", YES | {"1.0"}))
    nb = nb[nb["dob_d"].notna() & (nb["dob_d"] <= TODAY)].copy()
    nb["d"] = nb["dob_d"]
    need_people(set(nb["key"]))
    enc_nb = enc_for({"patient": set(nb["patient"])})
    first_visit = enc_nb.dropna(subset=["d"]).sort_values("d").drop_duplicates(["cid", "patient"])
    first_visit = first_visit.set_index(pd.Index(pkey(first_visit)))["facility"]
    nb["facility"] = [first_visit.get(k) for k in nb["key"]]
    nb["mkey"] = pkey(nb, "parent")
    nb.loc[nb["parent"].isna(), "mkey"] = None
    need_people(set(nb["mkey"].dropna()))
    nb["mother_age"] = (nb["d"] - pd.to_datetime(nb["mkey"].map(P_["dob_d"]), errors="coerce")).dt.days / 365.25

    # ---------------- deaths (patient record, inpatient record)
    pdead = ptab(pc.or_(lower_in("deceased", YES | {"1.0"}),
                        pc.and_(pc.is_valid(PT["death_date"]), pc.not_equal(pc.cast(PT["death_date"], pa.string()), ""))))
    pdead = pdead[["key", "death_date"]].rename(columns={"death_date": "dd"})
    ip = load(F["inpatient"], ["cid", "patient", "is_deceased", "death_date", "facility", "cause"])
    if len(ip):
        ip["cid"] = ip["cid"].fillna("")
        ip["key"] = pkey(ip)
        ip["ddate"] = day(ip["death_date"])
    deaths = pd.concat([pdead.assign(ddate=day(pdead["dd"]), facility=None)[["key", "ddate", "facility"]],
                        ip[["key", "ddate", "facility"]] if len(ip) else None], ignore_index=True)
    usable = deaths["ddate"].notna() & (deaths["ddate"] <= END)
    no_date_keys = set(deaths["key"]) - set(deaths.loc[usable, "key"])    # deceased, but no usable death date
    deaths = deaths[usable].sort_values(["key", "ddate", "facility"], na_position="last") \
        .drop_duplicates("key")
    deaths["d"] = deaths["ddate"]
    deaths = with_person(deaths)
    deaths = deaths[deaths["dob_d"].isna() | (deaths["age_days"] >= 0)]
    deaths["cid"] = [k[0] for k in deaths["key"]]

    # ---------------- diagnoses -> encounter date, facility
    dx = load(F["dx"], ["cid", "note_id", "parenttype", "diagnosis_code", "entry_code", "description_mapping", "description"])
    dxe = pd.DataFrame(columns=["key", "d", "facility", "cid", "text"])
    if len(dx):
        dx["cid"] = dx["cid"].fillna("")
        dx["text"] = (dx["diagnosis_code"].fillna("") + " " + dx["entry_code"].fillna("") + " "
                      + dx["description_mapping"].fillna("") + " " + dx["description"].fillna("")).str.strip()
        via = dx["parenttype"].fillna("Doctors Notes") == "Doctors Notes"
        notes = load(F["notes"], ["cid", "note_id", "patient", "encounter_id"], {"note_id": set(dx.loc[via, "note_id"].dropna())})
        notes["cid"] = notes["cid"].fillna("")
        a1 = dx[via].merge(notes.drop_duplicates(["cid", "note_id"]), on=["cid", "note_id"])
        a2 = dx[dx["parenttype"] == "Patient Encounter"].rename(columns={"note_id": "encounter_id"}).assign(patient=None)
        dxe = pd.concat([a1, a2], ignore_index=True)
        enc_dx = enc_for({"encounter_id": set(dxe["encounter_id"].dropna())})
        dxe = dxe.merge(enc_dx[["cid", "encounter_id", "patient", "d", "facility"]].rename(columns={"patient": "ep"}),
                        on=["cid", "encounter_id"])
        dxe["patient"] = dxe["patient"].fillna(dxe["ep"])
        dxe = dxe.dropna(subset=["patient", "d"])
        dxe = dxe[dxe["d"] <= TODAY]
        dxe["key"] = pkey(dxe)
    t = dxe["text"].fillna("")
    obst = dxe[(t.str.contains(OBST, case=False, regex=True) & ~t.str.contains(NOT_OBST, case=False, regex=True))
               | t.str.contains(STILL, case=False, regex=True)]
    still_dx = dxe[t.str.contains(STILL, case=False, regex=True)].drop_duplicates(["key", "d"])
    sepsis = with_person(dxe[t.str.contains(SEPSIS, case=False, regex=True)].drop_duplicates(["key", "d"]))
    diarr = with_person(dxe[t.str.contains(DIARR, case=False, regex=True)].drop_duplicates(["key", "d"]))

    # ---------------- procedures: deliveries (one per mother within 2 days; C-section wins) and FP procedures
    pr = load(F["procedures"], ["cid", "patient", "template", "date", "status", "facility"])
    pr["cid"] = pr["cid"].fillna("")
    pr = pr[~pr["status"].fillna("").str.contains(r"cancel|reject", case=False, regex=True)]
    pr["d"] = day(pr["date"])
    pr = pr.dropna(subset=["d", "patient"])
    pr = pr[pr["d"] <= TODAY]
    pr["key"] = pkey(pr)
    tt = pr["template"].fillna("")
    notp = tt.str.contains(NOT_PROC, case=False, regex=True)
    dl = pr[tt.str.contains(DELIVERY, case=False, regex=True) & ~notp].copy()
    dl["cs"] = dl["template"].str.contains(CSECTION, case=False, regex=True)
    dl["breech"] = dl["template"].str.contains("breech", case=False, regex=True)
    dl = dl.sort_values(["key", "d", "cs"], ascending=[True, True, False])
    gap = dl.groupby("key")["d"].diff().dt.days
    dl["episode"] = ((gap.isna()) | (gap > 2)).cumsum()
    deliveries = dl.groupby("episode").agg(key=("key", "first"), d=("d", "first"), cs=("cs", "any"),
                                           breech=("breech", "any"), facility=("facility", "first"),
                                           cid=("cid", "first")).reset_index(drop=True)
    deliveries = with_person(deliveries)
    fp_proc = pr[tt.str.contains(FP_PROC, case=False, regex=True) & ~notp][["key", "d", "facility", "cid"]]
    say(f"[procedures] deliveries {len(deliveries):,} | FP procedures {len(fp_proc):,}")

    # ---------------- death notifications
    dn = load(F["notifications"], ["cid", "patient", "date", "ntype", "pregnant", "stillborn", "baby_outcome",
                                   "period", "audited", "facility", "age_days", "docstatus"])
    dn = dn[dn["docstatus"].fillna("0").astype(str) != "2"]            # cancelled notifications excluded
    if len(dn):
        dn["cid"] = dn["cid"].fillna("")
        dn["d"] = day(dn["date"])
        dn = dn.dropna(subset=["d"])
        dn = dn[dn["d"] <= END]
        dn["key"] = [(c, p) if isinstance(p, str) and p else (c, f"notification-{i}")
                     for i, (c, p) in enumerate(zip(dn["cid"], dn["patient"]))]
        dn = dn.drop_duplicates(["key", "d"]).reset_index(drop=True)
        low = lambda c: dn[c].fillna("").astype(str).str.strip().str.lower()
        nt, pg, po, bo, sb = low("ntype"), low("pregnant"), low("period"), low("baby_outcome"), low("stillborn")
        baby_form = nt.isin(["neonatal", "perinatal"]) | po.isin(["early neonatal", "late neonatal", "antepartum", "intrapartum"])
        # age_at_death_days = 0 is also what EMPTY notifications carry: it is an age only on a neonatal / perinatal form
        ad = pd.to_numeric(dn["age_days"], errors="coerce")
        ad = ad.where((ad > 0) | baby_form)
        dn["unclassifiable"] = (nt == "") & (pg == "") & (po == "") & ad.isna()
        # the deceased's own age: patient record (date of birth) first, else age_at_death_days
        dn["n_age_days"] = ad
        dn = with_person(dn)                          # sex and date of birth of the deceased (patient record)
        dn["age_y"] = dn["age_y"].where(dn["age_y"].notna(), dn["n_age_days"] / 365.25)
        adult = dn["age_y"] >= 10                     # the 'stillborn' / 'baby outcome' fields of a woman's
        #                                               notification describe her baby: she is not a stillbirth
        dn["still"] = ((sb == "yes") | bo.str.contains("stillbirth") | po.isin(["antepartum", "intrapartum"])) \
            & (baby_form | ~adult)                    # a perinatal form filed on the mother's record stays a stillbirth
        dn["baby_form"] = baby_form
        dn["fresh"] = dn["still"] & (bo.str.contains("fresh") | ((bo == "") & (po == "intrapartum")))
        dn["macerated"] = dn["still"] & (bo.str.contains("macerat") | ((bo == "") & (po == "antepartum")))
        dn["neonatal"] = ~dn["still"] & ((nt == "neonatal") | po.isin(["early neonatal", "late neonatal"]) | ad.between(0, 28))
        dn["early_neonatal"] = dn["neonatal"] & ((po == "early neonatal") | ad.between(0, 6))
        dn["audited"] = is_yes(dn["audited"])
        # MATERNAL: type 'Maternal' or 'pregnant / within 6 weeks post delivery' - for a woman 10-55 only. On a
        # neonatal / perinatal / stillbirth form the pregnancy field describes the MOTHER of the deceased baby.
        flagged = (nt == "maternal") | pg.isin(["pregnant", "within 6 weeks post delivery"])
        male = dn["sex"].fillna("").astype(str).str.strip().str.lower().str.startswith("m")
        why = np.select([baby_form | dn["still"], male, dn["age_y"].notna() & ~dn["age_y"].between(10, 56)],
                        ["neonatal / perinatal / stillbirth notification", "deceased is male",
                         "deceased not aged 10-55"], "")
        dn["maternal"] = flagged & (why == "")
        dn["maternal_rejected"] = np.where(flagged & (why != ""), why, "")
        dn["n_type"], dn["n_pregnant"] = dn["ntype"].fillna(""), dn["pregnant"].fillna("")
    else:
        dn = pd.DataFrame(columns=["key", "d", "facility", "cid", "maternal", "still", "fresh", "macerated",
                                   "neonatal", "early_neonatal", "audited", "unclassifiable", "maternal_rejected",
                                   "n_type", "n_pregnant", "age_y", "sex", "baby_form"])

    # ---------------- maternal deaths from linked records: women 10-55 dying within 42 days of a delivery,
    #                  a registered birth, a pregnancy diagnosis, or with an obstetric cause of death
    #                  (age unknown is kept: no date of birth; her records in other counties link through the CR ID)
    md = deaths[deaths["female"].fillna(False) & (deaths["age_y"].between(10, 56) | deaths["age_y"].isna())]
    cod = ip[ip["cause"].fillna("").str.contains(OBST, case=False, regex=True)
             & ~ip["cause"].fillna("").str.contains(NOT_OBST, case=False, regex=True)] if len(ip) else ip
    ev = pd.concat([deliveries[["key", "d"]].assign(ev=np.where(deliveries["cs"], "delivery (caesarean section)", "delivery")),
                    nb.dropna(subset=["mkey"])[["mkey", "d"]].rename(columns={"mkey": "key"}).assign(ev="newborn registered to her"),
                    obst[["key", "d"]].assign(ev="diagnosis: " + obst["text"].fillna("").str.slice(0, 80)),
                    cod.dropna(subset=["ddate"])[["key", "ddate"]].rename(columns={"ddate": "d"}).assign(
                        ev="cause of death: " + cod["cause"].fillna("").str.slice(0, 80)) if len(cod) else None],
                   ignore_index=True)
    ev["d"] = pd.to_datetime(ev["d"], errors="coerce")
    ev["lk"] = lkey(ev["key"])
    md_l = md.rename(columns={"d": "dd"}).assign(key=lkey(md["key"]))
    md_linked = md[within(md_l, ev.assign(key=ev["lk"]), "dd", "d", -42, 0)]
    nn_linked = deaths[deaths["age_days"].between(0, 28)]

    # ---------------- programmes, forms, drugs
    pg_ = load(F["programs"], ["cid", "patient", "program", "date", "voided", "facility"])
    pg_ = pg_[~is_yes(pg_["voided"])] if len(pg_) else pg_
    pg_["cid"] = pg_["cid"].fillna("")
    pg_["d"] = day(pg_["date"])
    pg_ = pg_.dropna(subset=["d", "patient"])
    pg_["key"] = pkey(pg_)
    pcls = classify(pg_["program"], PROGRAMS)
    prog = {k: with_person(pg_[pcls[k]].drop_duplicates(["key", "d"])) for k in PROGRAMS}

    fm = load(F["forms"], ["cid", "patient", "form", "created", "facility"])
    fm["cid"] = fm["cid"].fillna("")
    fm["d"] = day(fm["created"])
    fm = fm.dropna(subset=["d", "patient"])
    fm["key"] = pkey(fm)
    fcls = classify(fm["form"], FORMS)
    form = {k: with_person(fm[fcls[k]].drop_duplicates(["key", "d"])) for k in FORMS}

    dr = load(F["drugs"], ["cid", "patient", "drug", "date", "parent"])
    dr["cid"] = dr["cid"].fillna("")
    dr["d"] = day(dr["date"])
    enc_dr = enc_for({"encounter_id": set(dr["parent"].dropna())}) if len(dr) else enc_for({"encounter_id": set()})
    enc_fac = enc_dr.set_index(["cid", "encounter_id"])["facility"]
    dr["facility"] = [enc_fac.get((c, p)) for c, p in zip(dr["cid"], dr["parent"])]
    if len(dr):
        vd = enc_dr.set_index(["cid", "encounter_id"])["d"]
        miss = dr["d"].isna()
        dr.loc[miss, "d"] = [vd.get((c, p)) for c, p in zip(dr.loc[miss, "cid"], dr.loc[miss, "parent"])]
    dr = dr.dropna(subset=["d", "patient"])
    dr["d"] = pd.to_datetime(dr["d"])
    dr["key"] = pkey(dr)
    dcls = classify(dr["drug"], DRUGS)
    drug = {k: with_person(dr[dcls[k]].drop_duplicates(["key", "d"])) for k in DRUGS}

    # ---------------- vitals: BP (for ANC) and growth (under 5)
    kids = PT.filter(pc.fill_null(pc.greater_equal(pc.cast(PT["dob"], pa.string()),
                                                   (y0 - pd.Timedelta(days=5 * 366)).strftime("%Y-%m-%d")), False))
    who = set(prog["anc"]["patient"].dropna()) | set(pc.cast(kids["patient"], pa.string()).to_pylist())
    vs = load(F["vitals"], ["cid", "patient", "date", "systolic", "diastolic", "bp", "height", "weight", "muac", "facility"],
              {"patient": who})
    vs["cid"] = vs["cid"].fillna("")
    vs["d"] = day(vs["date"])
    vs = vs.dropna(subset=["d", "patient"])
    vs["key"] = pkey(vs)
    sp = vs["bp"].astype(str).str.extract(r"(\d{2,3})\s*/\s*(\d{2,3})").astype(float)
    sbp, dbp = number(vs["systolic"]).fillna(sp[0]), number(vs["diastolic"]).fillna(sp[1])
    bp_ok = sbp.between(60, 300) & dbp.between(30, 200) & (sbp > dbp)
    bp_days = vs[bp_ok][["key", "d"]].drop_duplicates()
    gr = with_person(vs[(vs["d"] >= y0) & (vs["d"] <= y1)].copy())
    gr = gr[gr["age_days"].between(0, 5 * 365.25 - 1)]
    gr["age_m"] = gr["age_days"] / 30.4375
    gr["h"], gr["w"], gr["mu"] = number(gr["height"]), number(gr["weight"]), number(gr["muac"])
    gr.loc[gr["mu"] > 30, "mu"] = gr["mu"] / 10
    gr.loc[~gr["h"].between(40, 130), "h"] = np.nan
    gr.loc[~gr["w"].between(1.5, 35), "w"] = np.nan
    gr.loc[~gr["mu"].between(7, 25), "mu"] = np.nan
    gr["month"] = gr["d"].dt.strftime("%Y-%m")
    growth = gr.sort_values("d").groupby(["key", "month"]).last().reset_index() if len(gr) else gr

    # ================= the counts
    rows = []
    want = {c.strip().lower() for c in a.counties.split(",")} if a.counties else None

    def add(ind_id, name, df, date_col="d", mask=None, unique_by_month=True):
        if df is None or len(df) == 0:
            rows.append((None, None, None, ind_id, name, 0))
            return
        x = df if mask is None else df[mask.reindex(df.index).fillna(False).astype(bool)]
        x = x[(x[date_col] >= y0) & (x[date_col] <= y1)].copy()
        x["cid"] = [k[0] for k in x["key"]] if "key" in x else x["cid"]
        if want:
            x = x[x["cid"].astype(str).str.lower().isin(want)]
        x["month"] = x[date_col].dt.strftime("%Y-%m")
        x["facility"] = x["facility"].fillna("Unknown") if "facility" in x else "Unknown"
        if unique_by_month and "key" in x:
            x = x.drop_duplicates(["key", "month"])
        g = x.groupby(["month", "cid", "facility"]).size()
        if g.empty:
            rows.append((None, None, None, ind_id, name, 0))
        for (m, c, f), n in g.items():
            rows.append((m, c, f, ind_id, name, int(n)))

    female = lambda df: df["female"].fillna(False)
    age = lambda df, lo, hi: df["age_y"].between(lo, hi, inclusive="left")
    # deliveries and births
    add("MH-16", "Facility deliveries", deliveries, unique_by_month=False)
    add("MH-17", "Caesarean sections", deliveries, mask=deliveries["cs"], unique_by_month=False)
    add("MH-16", "Vaginal deliveries", deliveries, mask=~deliveries["cs"], unique_by_month=False)
    add("MH-16", "Breech deliveries", deliveries, mask=deliveries["breech"], unique_by_month=False)
    add("MI-09", "Deliveries to mothers aged 10-19", deliveries, mask=age(deliveries, 10, 20), unique_by_month=False)
    add("DEN", "Registered newborns (live births in the system)", nb, unique_by_month=False)
    add("MI-09", "Registered newborns, mother aged 10-19", nb, mask=nb["mother_age"].between(10, 20, inclusive="left"),
        unique_by_month=False)
    # deaths
    add("MI-02", "Maternal deaths - death notifications", dn, mask=dn["maternal"])
    add("MI-02", "Maternal deaths - linked records (within 42 days of a delivery, birth or pregnancy diagnosis)",
        md_linked.assign(d=md_linked["d"]))
    # one row per woman: the record (patient / inpatient) death date first, else the notification; facility: the
    # first one known in that order
    both = pd.concat([md_linked[["key", "d", "facility"]].assign(_s=0), dn[dn["maternal"]][["key", "d", "facility"]].assign(_s=1)],
                     ignore_index=True)
    both["lk"] = lkey(both["key"])
    both = both.sort_values("_s", kind="stable")
    fac_known = both.dropna(subset=["facility"]).drop_duplicates("lk").set_index("lk")["facility"]
    both = both.drop_duplicates("lk")
    both["facility"] = both["lk"].map(fac_known)
    add("MI-02", "Maternal deaths - any source (deduplicated)", both)
    add("MH-19", "Maternal deaths audited (death notification)", dn, mask=dn["maternal"] & dn["audited"])
    # completeness of death recording
    alld = pd.concat([deaths[["key", "d", "facility"]].assign(_s=0), dn[["key", "d", "facility"]].assign(_s=1)],
                     ignore_index=True)
    alld["lk"] = lkey(alld["key"])
    alld = alld.sort_values("_s", kind="stable")
    fac_known = alld.dropna(subset=["facility"]).drop_duplicates("lk").set_index("lk")["facility"]
    alld = alld.drop_duplicates("lk")
    alld["facility"] = alld["lk"].map(fac_known)
    add("QA-01", "Deaths recorded, all causes (patient / inpatient records or death notifications)", alld)
    add("QA-02", "Death notifications that cannot be classified (no type, pregnancy status, period or age)", dn,
        mask=dn["unclassifiable"])
    fx = alld[(alld["d"] >= y0) & (alld["d"] <= y1) & alld["facility"].notna()]
    for (mo, c, f), _ in fx.groupby([fx["d"].dt.strftime("%Y-%m"), [k[0] for k in fx["key"]], "facility"]).size().items():
        if not want or str(c).lower() in want:
            rows.append((mo, c, f, "QA-03", "Facilities recording at least one death", 1))
    add("MI-05", "Neonatal deaths 0-28 days - death notifications", dn, mask=dn["neonatal"])
    add("MI-05", "Neonatal deaths 0-28 days - patient / inpatient records", nn_linked)
    add("MI-08", "Early neonatal deaths 0-6 days - death notifications", dn, mask=dn["early_neonatal"])
    add("MI-08", "Early neonatal deaths 0-6 days - patient / inpatient records", nn_linked, mask=nn_linked["age_days"].between(0, 6))
    add("MI-06", "Stillbirths - death notifications", dn, mask=dn["still"])
    add("MI-07", "Fresh stillbirths - death notifications", dn, mask=dn["fresh"])
    add("MI-07", "Macerated stillbirths - death notifications", dn, mask=dn["macerated"])
    add("MI-06", "Stillbirths - recorded as a diagnosis", still_dx)
    # ANC / PNC
    anc = prog["anc"]
    add("MH-03", "New ANC clients (ANC enrolments)", anc)
    add("AD-01", "New ANC clients aged 10-19", anc, mask=age(anc, 10, 20))
    add("AD-01", "New ANC clients aged 10-14", anc, mask=age(anc, 10, 15))
    add("AD-02", "New ANC clients aged 15-19", anc, mask=age(anc, 15, 20))
    anc_bp = within(anc, bp_days, "d", "d", 0, 0)
    add("MH-08", "New ANC clients with BP measured on the enrolment day", anc, mask=anc_bp)
    ifas = pd.concat([form["ifas"][["key", "d", "facility", "female", "age_y"]],
                      drug["ifas"][["key", "d", "facility", "female", "age_y"]]])
    ifas = ifas[female(ifas) & age(ifas, 10, 50)]
    ifas_anc = ifas[within(ifas, anc, "d", "d", -300, 0)]
    add("MH-12", "ANC clients given IFAS (form or prescription, ANC enrolment in the previous 300 days)", ifas_anc)
    pnc_m = pd.concat([form["pnc_mother"][["key", "d"]], prog["pnc"][["key", "d"]]])
    add("MH-21", "Deliveries with mother's PNC within 2 days", deliveries,
        mask=within(deliveries, pnc_m, "d", "d", 0, 2), unique_by_month=False)
    add("DEN", "PNC enrolments (mothers)", prog["pnc"])
    # newborn / child
    add("NB-01", "Registered newborns with PNC (child) within 2 days of birth", nb,
        mask=within(nb, form["pnc_child"], "d", "d", 0, 2), unique_by_month=False)
    neo_sep = sepsis[sepsis["age_days"].between(0, 28)]
    add("NB-05", "Newborns (0-28 days) diagnosed with sepsis", neo_sep)
    add("NB-05", "Newborns with sepsis given antibiotics (same or next day)", neo_sep,
        mask=within(neo_sep, drug["antibiotic"], "d", "d", 0, 1))
    add("NB-06", "Children under 1 given BCG (BCG form)", form["bcg"], mask=form["bcg"]["age_days"].between(0, 364))
    add("CH-04", "Children under 1 given measles-rubella (MR form)", form["measles"],
        mask=form["measles"]["age_days"].between(0, 364))
    u5d = diarr[diarr["age_days"].between(0, 5 * 365.25 - 1)]
    has_ors, has_zinc = within(u5d, drug["ors"], "d", "d", 0, 1), within(u5d, drug["zinc"], "d", "d", 0, 1)
    add("CH-09", "Under-5 diarrhoea cases", u5d)
    add("CH-09", "Under-5 diarrhoea cases given ORS and zinc", u5d, mask=has_ors & has_zinc)
    add("CH-09", "Under-5 diarrhoea cases given ORS", u5d, mask=has_ors)
    add("CH-09", "Under-5 diarrhoea cases given zinc", u5d, mask=has_zinc)
    dw = pd.concat([form["deworm"][["key", "d", "facility", "age_y"]], drug["deworm"][["key", "d", "facility", "age_y"]]])
    add("CH-10", "Children aged 5-14 dewormed (form or prescription)", dw, mask=age(dw, 5, 15))
    add("NB-03", "KMC forms (babies)", form["kmc"])
    add("NU-04", "Exclusive breastfeeding forms, infants under 6 months", form["ebf"],
        mask=form["ebf"]["age_days"].between(0, 182))
    add("NU-07", "Vitamin A forms, children 6-59 months", form["vas"], mask=form["vas"]["age_days"].between(183, 1825))
    add("MH-10", "LLIN forms, women 10-49", form["llin"], mask=female(form["llin"]) & age(form["llin"], 10, 50))
    # family planning
    fp = pd.concat([prog["fp"][["key", "d", "facility", "female", "age_y"]], form["fp"][["key", "d", "facility", "female", "age_y"]],
                    with_person(fp_proc)[["key", "d", "facility", "female", "age_y"]],
                    drug["fp"][["key", "d", "facility", "female", "age_y"]]])
    add("FP-08", "Women 15-49 receiving family planning", fp, mask=female(fp) & age(fp, 15, 50))
    add("FP-05", "Deliveries with FP started within 2 days (before discharge)", deliveries,
        mask=within(deliveries, fp, "d", "d", 0, 2), unique_by_month=False)
    add("FP-06", "Deliveries with FP started within 42 days", deliveries,
        mask=within(deliveries, fp, "d", "d", 0, 42), unique_by_month=False)
    # nutrition
    if len(growth):
        add("NU-08", "Children under 5 measured (height and weight)", growth, mask=growth["h"].notna() & growth["w"].notna())
        six = growth["age_m"] >= 6
        add("NU-09", "Children 6-59 months with MUAC measured", growth, mask=six & growth["mu"].notna())
        add("NU-09", "Children 6-59 months with MUAC < 11.5 cm (severe)", growth, mask=six & (growth["mu"] < 11.5))
        add("NU-09", "Children 6-59 months with MUAC 11.5-12.4 cm (moderate)", growth,
            mask=six & growth["mu"].between(11.5, 12.5, inclusive="left"))
    other = [("CWC", "cwc"), ("EPI", "epi"), ("Maternity forms", "maternity"), ("Nutrition services", "nutrition"),
             ("PMTCT", "pmtct"), ("Family planning", "fp")]
    for label, k in other:
        add("DEN", f"{label} enrolments", prog[k])

    # ================= maternal death line list (MPDSR review; holds patient IDs)
    evy = ev.dropna(subset=["d"]).copy()
    evy["ls"] = evy["lk"].astype(str)

    def evidence(people, lo=0, hi=42):
        """nearest pregnancy evidence lo..hi days before each person's date: {(str(lk), date): dict}."""
        p = pd.DataFrame({"ls": [str(x) for x in people["lk"]], "dd": pd.to_datetime(people["dd"])}).drop_duplicates()
        m = p.merge(evy[["ls", "key", "d", "ev"]], on="ls")
        m["gap"] = (m["dd"] - m["d"]).dt.days
        m = m[m["gap"].between(lo, hi)]
        n = m.groupby(["ls", "dd"]).size()
        m = m.sort_values(["gap", "d"]).drop_duplicates(["ls", "dd"])
        return {(r.ls, r.dd): dict(ev=r.ev, d=r.d, gap=int(r.gap), county=r.key[0], n=int(n[(r.ls, r.dd)]))
                for r in m.itertuples()}

    def tf(v):
        return bool(v) if pd.notna(v) else False

    LL = []
    yr = lambda s: (s >= y0) & (s <= y1)
    dnm = dn[dn["maternal"]].copy()
    dnm["ls"] = [str(x) for x in lkey(dnm["key"])]
    lnk = md_linked.copy()
    lnk["ls"] = [str(x) for x in lkey(lnk["key"])]
    cnt = both[yr(both["d"])].copy()
    cnt["ls"] = [str(x) for x in cnt["lk"]]
    dna = dn.copy()
    dna["ls"] = [str(x) for x in lkey(dna["key"])]
    for r in cnt.to_dict("records"):
        L1, N1, NA_ = lnk[lnk["ls"] == r["ls"]], dnm[dnm["ls"] == r["ls"]], dna[dna["ls"] == r["ls"]]
        notes = []
        if len(NA_) and NA_["baby_form"].all():
            notes.append("her record's only death notification is a neonatal / perinatal one - confirm that the woman "
                         "died (not only the baby)")
        src = (L1 if len(L1) else N1).iloc[0]
        if pd.isna(src["age_y"]):
            notes.append("no date of birth")
        LL.append(dict(status="counted", reason="; ".join(notes), key=r["key"], ls=r["ls"], dd=r["d"], facility=r["facility"],
                       age_y=src["age_y"], sex=src["sex"], in_records=len(L1) > 0, in_notification=len(N1) > 0,
                       notification_type="; ".join(N1["n_type"].unique()) if len(N1) else "",
                       notification_pregnancy="; ".join(N1["n_pregnant"].unique()) if len(N1) else ""))
    for r in dn[(dn["maternal_rejected"] != "") & yr(dn["d"])].to_dict("records"):
        LL.append(dict(status="not counted - notification rejected", reason=r["maternal_rejected"], key=r["key"],
                       ls=str(lkey([r["key"]])[0]), dd=r["d"], facility=r["facility"], age_y=r["age_y"], sex=r["sex"],
                       in_records=False, in_notification=True, notification_type=r["n_type"],
                       notification_pregnancy=r["n_pregnant"]))
    # dated deaths with pregnancy evidence 0-42 days before that are not counted because of sex / age (children
    # under 10 left out: a baby's record often carries its mother's delivery diagnoses)
    oth = deaths[yr(deaths["d"]) & ~deaths["key"].isin(set(md["key"])) & ~(deaths["age_y"] < 10)].copy()
    if len(oth):
        oth["lk"], oth["dd"] = lkey(oth["key"]), oth["d"]
        e = evidence(oth)
        done = set(cnt["ls"])
        for r in oth.to_dict("records"):
            ls = str(r["lk"])
            if (ls, r["dd"]) not in e or ls in done:
                continue
            why = "age outside 10-55 (check date of birth)" if tf(r["female"]) else "sex recorded as not female"
            LL.append(dict(status="not counted - check record", reason=why, key=r["key"], ls=ls, dd=r["d"],
                           facility=r["facility"], age_y=r["age_y"], sex=r["sex"], in_records=True,
                           in_notification=False, notification_type="", notification_pregnancy=""))
    # marked deceased with NO usable death date, and pregnancy evidence in the year (cannot be placed in a month)
    if no_date_keys:
        nd = pd.DataFrame({"key": list(no_date_keys)})
        nd["ls"] = [str(x) for x in lkey(nd["key"])]
        last = evy[yr(evy["d"]) & evy["ls"].isin(set(nd["ls"]))].sort_values("d").drop_duplicates("ls", keep="last")
        nd = nd.merge(last[["ls", "d", "ev"]], on="ls")
        if len(nd):
            need_people(set(nd["key"]))
            info = {k: (dob, sx) for k, dob, sx in zip(P_.index, P_["dob_d"], P_["sex"])}
            for r in nd.to_dict("records"):
                dob, sx = info.get(r["key"], (pd.NaT, None))
                if str(sx).strip().lower().startswith("m"):
                    continue
                LL.append(dict(status="not counted - no death date", reason="marked deceased, no death date",
                               key=r["key"], ls=r["ls"], dd=pd.NaT, facility=None,
                               age_y=(r["d"] - pd.Timestamp(dob)).days / 365.25 if pd.notna(dob) else np.nan,
                               sex=sx, in_records=True, in_notification=False, notification_type="",
                               notification_pregnancy="", _ev=r["ev"], _evd=r["d"]))
    LLd = pd.DataFrame(LL)
    if len(LLd):
        dated = LLd[LLd["dd"].notna()].rename(columns={"ls": "lk"})
        e = evidence(dated) if len(dated) else {}
        out_ = []
        for r in LLd.to_dict("records"):
            x = e.get((r["ls"], r["dd"])) if pd.notna(r["dd"]) else None
            if x is None and isinstance(r.get("_ev"), str):
                x = dict(ev=r["_ev"], d=r["_evd"], gap=None, county=r["key"][0], n=None)
            out_.append(dict(
                status=r["status"], reason=r["reason"], county=r["key"][0], facility=r["facility"],
                death_date=r["dd"].strftime("%Y-%m-%d") if pd.notna(r["dd"]) else "",
                age_years=round(r["age_y"], 1) + 0.0 if pd.notna(r["age_y"]) else None, sex=r["sex"],
                in_records=r["in_records"], in_notification=r["in_notification"],
                notification_type=r["notification_type"], notification_pregnancy_field=r["notification_pregnancy"],
                evidence=x["ev"] if x else "", evidence_date=x["d"].strftime("%Y-%m-%d") if x else "",
                days_evidence_to_death=x["gap"] if x else None, evidence_items_in_42_days=x["n"] if x else None,
                evidence_in_other_county=x["county"] if x and x["county"] != r["key"][0] else "",
                patient_id=r["key"][1] if not str(r["key"][1]).startswith("notification-") else ""))
        LLd = pd.DataFrame(out_).sort_values(["status", "county", "death_date"]).reset_index(drop=True)
    say(f"[maternal deaths] counted {int((LLd['status'] == 'counted').sum()) if len(LLd) else 0} | "
        f"line list {len(LLd)} rows")

    # ================= output
    L = pd.DataFrame(rows, columns=["month", "county", "facility", "indicator_id", "indicator", "value"])
    order = list(dict.fromkeys(zip(L["indicator_id"], L["indicator"])))
    L = L.dropna(subset=["month"])
    months = pd.period_range(y0, y1, freq="M").strftime("%Y-%m").tolist()

    # death indicators: blank (no data) where the county / facility recorded no death of any cause that month
    DEATHS = {(i, n) for i, n in order if i in ("MI-02", "MH-19", "MI-05", "MI-07", "MI-08")
              or (i == "MI-06" and "notification" in n)}
    QA1 = L[L["indicator_id"] == "QA-01"]

    def wide(keys):
        base = pd.DataFrame(order, columns=["indicator_id", "indicator"])
        if keys:
            w = L.groupby(keys + ["indicator_id", "indicator", "month"])["value"].sum().unstack("month").reset_index()
        else:
            w = L.groupby(["indicator_id", "indicator", "month"])["value"].sum().unstack("month").reset_index()
            w = base.merge(w, on=["indicator_id", "indicator"], how="left")
        if keys == ["county"]:                      # every county gets every death row (0 vs no data visible)
            grid = pd.DataFrame([(c, i, n) for c in sorted(L["county"].dropna().unique()) for i, n in order
                                 if (i, n) in DEATHS], columns=["county", "indicator_id", "indicator"])
            w = grid.merge(w, how="outer", on=["county", "indicator_id", "indicator"])
        for m in months:
            if m not in w:
                w[m] = 0
        w[months] = w[months].fillna(0).astype("Int64")
        q = QA1.groupby(keys + ["month"])["value"].sum() if keys else QA1.groupby("month")["value"].sum()
        recorded = set(q[q > 0].index)
        dead = pd.Series([(i, n) in DEATHS for i, n in zip(w["indicator_id"], w["indicator"])], index=w.index)
        for m in months:
            has = pd.Series([((tuple(v) + (m,)) if keys else m) in recorded
                             for v in (w[keys].itertuples(index=False, name=None) if keys else [()] * len(w))], index=w.index)
            w.loc[dead & ~has, m] = pd.NA
        w[f"total_{a.year}"] = w[months].sum(axis=1, min_count=1).astype("Int64")
        w.loc[w["indicator_id"] == "QA-03", f"total_{a.year}"] = pd.NA      # a sum of months is not a facility count
        w = w[keys + ["indicator_id", "indicator"] + months + [f"total_{a.year}"]]
        if keys:
            pos = {k: i for i, k in enumerate(order)}
            w["_o"] = [pos.get((i, n), 999) for i, n in zip(w["indicator_id"], w["indicator"])]
            w = w.sort_values(keys + ["_o"]).drop(columns="_o")
        return w.rename(columns={m: pd.Period(m).strftime("%b_%Y").lower() for m in months})

    W0, W1, W2 = wide([]), wide(["county"]), wide(["county", "facility"])
    DEF = pd.DataFrame([
        ("MI-02", "Facility MMR = maternal deaths / live births x 100,000. Live births: registered newborns (DEN) or facility deliveries (MH-16). Use the deduplicated 'any source' count; compare with MPDSR."),
        ("MI-02 (sources)", "Linked records: a woman (female; aged 10-55, or no date of birth) dying 0-42 days after a delivery, a newborn registered to her, a pregnancy / obstetric diagnosis or an obstetric cause of death - in any county (client-registry ID). These are pregnancy-ASSOCIATED deaths: cause of death is almost never recorded, so incidental deaths cannot be excluded. Notifications: type 'Maternal' or deceased 'pregnant / within 6 weeks post delivery', excluding neonatal / perinatal / stillbirth notifications (their pregnancy field describes the mother) and deceased who are male or not aged 10-55. Each woman is counted once; see the CONFIDENTIAL line list for the evidence."),
        ("Death rows", "BLANK = no data: the county / facility recorded no death of any cause (QA-01) that month, so a 0 would be meaningless. 0 = deaths were recorded there, none of this kind. Death recording in the HMIS starts in earnest in July 2026; compare QA-01 with deliveries (MH-16) before reading any death count."),
        ("QA-01 / QA-02 / QA-03", "QA-01 deaths of any cause (one per person; patient / inpatient records or death notifications). QA-02 death notifications with no type, pregnancy status, period of death or age - they cannot be counted as maternal, neonatal or stillbirth. QA-03 facilities recording at least one death that month (no year total: the same facility appears in several months)."),
        ("MI-05 / MI-08 (notifications)", "Age at death 0 days counts as neonatal only on a neonatal / perinatal notification: empty notifications also carry 0."),
        ("MI-06 / MI-07 (notifications)", "Not counted from a woman's own (maternal / standard) notification: there 'stillborn' / 'baby outcome' describe her baby. A perinatal / neonatal notification counts even when it is filed on the mother's record."),
        ("MI-05 / MI-08", "Facility NMR = neonatal deaths / live births x 1,000. Perinatal = stillbirths + early neonatal deaths, per 1,000 total births."),
        ("MI-06 / MI-07", "Stillbirth rate = stillbirths / (stillbirths + live births) x 1,000. Fresh = baby outcome fresh (or intrapartum); macerated = macerated (or antepartum)."),
        ("MI-09", "Share of deliveries (or registered births) to mothers aged 10-19. The KDHS rate needs population data."),
        ("MH-16 / MH-17", "Deliveries from clinical_procedure (Vaginal / SVD / Normal / Breech delivery, Caesarean section); several records for one mother within 2 days = one delivery; C-section rate = MH-17 / MH-16."),
        ("MH-03 / AD-01 / AD-02", "New ANC clients = ANC programme enrolments. AD-01 = (aged 10-19) / new ANC clients. MH-03 / AD-02 denominators (expected pregnancies) are external."),
        ("MH-08", "New ANC clients with a valid BP on the enrolment day / new ANC clients."),
        ("MH-12", "Women 10-49 given IFAS (form or prescription) with an ANC enrolment in the previous 300 days."),
        ("MH-21 / NB-01", "PNC within 2 days (date level: the day of delivery / birth and the next 2 days) / deliveries or registered newborns."),
        ("NB-05", "Newborns 0-28 days with a sepsis diagnosis; given gentamicin / ampicillin / benzylpenicillin / ceftriaxone the same or next day."),
        ("NB-06 / CH-04", "Children under 1 with a BCG / measles-rubella form. Denominators (live births, surviving infants) are external."),
        ("CH-09", "Under-5 diarrhoea diagnoses (one per child per day) given ORS and zinc the same or next day / under-5 diarrhoea cases."),
        ("CH-10", "Children 5-14 with a deworming form or albendazole / mebendazole. Denominator (school-age population) external."),
        ("FP-05 / FP-06 / FP-08", "FP = FP programme enrolment, FP form, implant / IUCD insertion, tubal ligation, or FP drug (DMPA, levonorgestrel, COC). Post-partum = FP within 2 / 42 days of a delivery; FP-05 uses 2 days as a proxy for 'before discharge'."),
        ("NU-08 / NU-09", "Children under 5 with height and weight; MUAC < 11.5 cm = severe, 11.5-12.4 cm = moderate acute malnutrition. Stunting / wasting: load the WHO Anthro file."),
        ("NB-03 / NU-04 / NU-07 / MH-10", "Form counts only: the answers inside these forms (KMC eligibility, EBF yes/no, VAS dose, LLIN to pregnant women) are not yet read."),
        ("All", "Facility-based events in the HMIS (hmis_tiberbu_ingestion); cancelled records excluded; one count per person per month unless stated. Not KDHS estimates."),
    ], columns=["indicator_id", "how to use / definition"])

    RUN = pd.DataFrame([
        ("Run", pd.Timestamp.now().strftime("%Y-%m-%d %H:%M") + (" (offline: cached downloads only)" if a.offline else "")),
        ("Data cut-off (latest record date)", f"{DATA_TO:%d %b %Y}"),
        ("Last complete month", LAST_COMPLETE),
        ("Partial month", PARTIAL or "none"),
        ("Deaths dated after the cut-off", "not counted (typing errors)"),
        ("Maternal deaths counted (any source)", int(L.loc[L["indicator"] == "Maternal deaths - any source (deduplicated)", "value"].sum())),
        ("Maternal death line list", f"output/RMNCAH_maternal_deaths_linelist_{a.year}_CONFIDENTIAL.csv (patient IDs - MPDSR / data team only)"),
    ], columns=["item", "value"])
    os.makedirs("output", exist_ok=True)
    base = os.path.join("output", f"RMNCAH_aggregates_{a.year}")
    LLd.to_csv(os.path.join("output", f"RMNCAH_maternal_deaths_linelist_{a.year}_CONFIDENTIAL.csv"), index=False)
    L.to_csv(base + ".csv", index=False)
    try:
        cut = f"Data to {DATA_TO:%d %b %Y}" + (f"; {pd.Period(PARTIAL).strftime('%b %Y')} is partial." if PARTIAL else ".")
        blank = ("Death rows (MI-02, MH-19, MI-05 / MI-08, MI-06 / MI-07 notifications): a BLANK cell = no data - no death "
                 "of any cause was recorded there that month; 0 = deaths were recorded, none of this kind. ")
        NOTE = {"National monthly": "Death recording in the HMIS starts in earnest in July 2026 - read death counts "
                                    "with QA-01 (deaths recorded, all causes). " + cut,
                "By county": blank + cut, "By facility": blank + cut}
        with pd.ExcelWriter(base + ".xlsx") as w:
            for name, tab in (("National monthly", W0), ("By county", W1), ("By facility", W2)):
                pd.DataFrame([[NOTE[name]]]).to_excel(w, sheet_name=name, index=False, header=False)   # row 1: note
                tab.to_excel(w, sheet_name=name, index=False, startrow=2, freeze_panes=(3, 0))        # row 3: header
            DEF.to_excel(w, sheet_name="Indicators", index=False)
            RUN.to_excel(w, sheet_name="Run info", index=False)
    except PermissionError:
        say(f"!! {base}.xlsx is open in Excel - close it and run again (the .csv was saved)")
    if os.path.exists(base + ".db"):
        os.remove(base + ".db")
    con = sqlite3.connect(base + ".db")
    L.to_sql("monthly_counts", con, index=False)
    DEF.to_sql("definitions", con, index=False)
    RUN.astype(str).to_sql("run_info", con, index=False)
    con.execute("CREATE INDEX ix_mc ON monthly_counts(indicator_id, month, county)")
    con.commit()
    con.close()
    if len(growth):
        g = growth[growth["h"].notna() | growth["mu"].notna()]
        pd.DataFrame({"id": range(1, len(g) + 1),
                      "sex": g["sex"].astype(str).str.lower().str[0].map({"m": 1, "f": 2}).values,
                      "age_days": g["age_days"].values, "weight_kg": g["w"].round(2).values,
                      "height_cm": g["h"].round(1).values, "muac_cm": g["mu"].round(1).values,
                      "measure": np.where(g["age_m"] < 24, "L", "H"), "oedema": "n", "month": g["month"].values,
                      "county": [k[0] for k in g["key"]], "facility": g["facility"].fillna("Unknown").values}) \
            .to_csv(os.path.join("output", f"RMNCAH_growth_for_WHO_Anthro_{a.year}.csv"), index=False)
    pd.set_option("display.width", 250, "display.max_colwidth", 70)
    say("\n" + W0.to_string(index=False))
    say(f"\nSaved {base}.xlsx / .csv / .db  ({(time.time() - T0) / 60:.1f} min). Facility-based counts, not KDHS estimates.")
    POOL.shutdown()


if __name__ == "__main__":
    main()
