#!/usr/bin/env python3
"""
Run any data-lake script without typing the S3 endpoint and keys every time.

  python lake_run.py rmncah_monthly_counts.py            # run a script (keys are filled in automatically)
  python lake_run.py moh705_aggregate.py --start 2026-06-01 --end 2026-09-30   # options pass through
  python lake_run.py --save                              # save or change the keys
  python lake_run.py --forget                            # delete the saved keys

The first time, it asks for the endpoint, access key and secret key and saves them in
    %USERPROFILE%\\.dha_lake\\credentials.json   (Windows)   or   ~/.dha_lake/credentials.json   (Mac)
- a private folder in your user profile, NOT inside OneDrive, so the keys are never synced or shared.
"""
import getpass
import json
import os
import runpy
import sys
from pathlib import Path

STORE = Path.home() / ".dha_lake" / "credentials.json"
DEFAULT_ENDPOINT = "http://10.10.100.102:8000"


def save():
    print("Save data-lake keys (stored only on this computer, outside OneDrive).")
    endpoint = input(f"S3 endpoint [{DEFAULT_ENDPOINT}]: ").strip() or DEFAULT_ENDPOINT
    access = input("Access key: ").strip()
    secret = getpass.getpass("Secret key (hidden): ").strip()
    if not access or not secret:
        sys.exit("Access key and secret key are both needed - nothing saved.")
    STORE.parent.mkdir(parents=True, exist_ok=True)
    STORE.write_text(json.dumps({"AWS_ENDPOINT_URL": endpoint, "AWS_ACCESS_KEY_ID": access,
                                 "AWS_SECRET_ACCESS_KEY": secret}, indent=1))
    try:
        os.chmod(STORE, 0o600)                       # readable only by you (Mac / Linux)
    except OSError:
        pass
    print(f"Saved to {STORE}")


def load():
    if not STORE.exists():
        save()
    try:
        keys = json.loads(STORE.read_text())
    except (OSError, ValueError):
        sys.exit(f"Could not read {STORE}. Run:  python lake_run.py --save")
    for k, v in keys.items():
        os.environ.setdefault(k, v)                  # a key typed in this session still wins


def main():
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__)
        return
    if args[0] == "--save":
        save()
        return
    if args[0] == "--forget":
        if STORE.exists():
            STORE.unlink()
            print(f"Deleted {STORE}")
        else:
            print("No saved keys.")
        return
    script = args[0]
    if not Path(script).exists():
        sys.exit(f"Script not found: {script}  (run this from the folder that contains it)")
    load()
    print(f"Using saved data-lake keys ({STORE}) - endpoint {os.environ['AWS_ENDPOINT_URL']}")
    sys.argv = [script] + args[1:]
    sys.path.insert(0, str(Path(script).resolve().parent))
    runpy.run_path(script, run_name="__main__")


if __name__ == "__main__":
    main()
